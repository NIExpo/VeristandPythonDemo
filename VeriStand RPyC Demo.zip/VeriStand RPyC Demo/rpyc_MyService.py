import rpyc
import niveristand
import subprocess
from niveristand.legacy import NIVeriStand
from niveristand.errors import RunError
from niveristand import library
from niveristand import nivs_rt_sequence, NivsParam, realtimesequencetools, clientapi, run_py_as_rtseq
from niveristand.clientapi import BooleanValue, ChannelReference, DoubleValue
from niveristand.library import wait
from examples.engine_demo.engine_demo_basic import run_engine_demo
from examples.engine_demo.engine_demo_advanced import run_engine_demo_advanced

class MyService(rpyc.Service):
   exposed_niveristand = niveristand
   exposed_NIVeriStand = NIVeriStand
   exposed_subprocess = subprocess
   exposed_run_engine_demo = run_engine_demo
   exposed_run_engine_demo_advanced = run_engine_demo_advanced
   exposed_run_py_as_rtseq = run_py_as_rtseq
   exposed_RunError = RunError
   exposed_nivs_rt_sequence = nivs_rt_sequence
   exposed_NivsParam = NivsParam
   exposed_realtimesequencetools = realtimesequencetools
   exposed_BooleanValue = BooleanValue
   exposed_ChannelReference = ChannelReference
   exposed_DoubleValue = DoubleValue
   exposed_clientapi = clientapi
   exposed_wait = wait
   exposed_library = library

if __name__ == "__main__":
   from rpyc.utils.server import ThreadedServer
   t = ThreadedServer(MyService, port = 18861, protocol_config = {"allow_public_attrs" : True, "allow_all_attrs" : True})
   print("Starting the RPC Service")
   t.start()
